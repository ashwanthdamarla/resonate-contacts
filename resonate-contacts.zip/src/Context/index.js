import { createContext } from "react";

export const ContactsContext = createContext();
